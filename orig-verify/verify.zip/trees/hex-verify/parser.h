#include <stdio.h>

node_t *parse_tree(FILE *stream);
void print_tree(node_t *r);

